package com.example.javare;

public class MyClass {
}